<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<!-- Header -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item ">
            <img src="<?php echo e(url('img/1-min.jpg')); ?>" class="d-block w-100 img-fluid" alt="...">
        </div>
        <div class="carousel-item active">
            <img src="<?php echo e(url('img/2-min.jpg')); ?>" class="d-block w-100 img-fluid" alt="...">
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(url('img/semi final basket 1-min.jpg')); ?>" class="d-block w-100 img-fluid" alt="...">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
    <div class="container-fluid">

        <div class="mt-4">
            <div class="col-md-12 mb-5">
                <h2>What We Do</h2>
                <hr>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A deserunt neque tempore recusandae animi
                    soluta quasi? Asperiores rem dolore eaque vel, porro, soluta unde debitis aliquam laboriosam. Repellat
                    explicabo, maiores!</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis optio neque consectetur consequatur magni
                    in nisi, natus beatae quidem quam odit commodi ducimus totam eum, alias, adipisci nesciunt voluptate.
                    Voluptatum.</p>
                <a class="btn btn-primary btn-lg" href="#">Call to Action &raquo;</a>
            </div>
        </div>
    </div>

    <div class="bg-light">
        <div class="container mt-3 mb-3">
            <h1 class="text-center mb-4 pt-3">Our Popular Players </h1>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?php echo e(url('img/1-min.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the card's content.</p>
                            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Go somewhere</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?php echo e(url('img/1-min.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the card's content.</p>
                            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Go somewhere</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?php echo e(url('img/1-min.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the card's content.</p>
                            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Go somewhere</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="mt-1 mb-3">
                    <p class="text-right pb-3" style="font-size: 15pt; margin-right: 120px;"><a href="<?php echo e(route('profiles')); ?>" style="text-decoration: none;" > view more >>> </a></p>
                </div>
    </div>
    <div class="col-md-12">
        <h2>Contact Us</h2>
        <hr>
        <address>
            <strong>Start Bootstrap</strong>
            <br>3481 Melrose Place
            <br>Beverly Hills, CA 90210
            <br>
        </address>
        <address>
            <abbr title="Phone">P:</abbr>
            (123) 456-7890
            <br>
            <abbr title="Email">E:</abbr>
            <a href="mailto:#">name@example.com</a>
        </address>
    </div>
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaihanWisesa\resources\views/home.blade.php ENDPATH**/ ?>