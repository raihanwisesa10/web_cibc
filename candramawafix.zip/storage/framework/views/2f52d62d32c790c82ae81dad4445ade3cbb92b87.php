
<?php $__env->startSection('content'); ?>


                <!-- End of Topbar -->

                <div class="container">
                    <h3 class="text-center">Tabel Aktivitas Pemain</h3>
                    <a href="<?php echo e(url('dashboard/activity/create')); ?>" class="btn btn-success mb-1">Tambah Data Pemain</a>
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Point</th>
                                <th scope="col">Assist</th>
                                <th scope="col">Steal</th>
                                <th scope="col">Block</th>
                                <th scope="col">Rebound</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($act->id_pemain); ?></th>
                                <td><?php echo e($act->nama); ?></td>
                                <td><?php echo e($act->point); ?></td>
                                <td><?php echo e($act->assist); ?></td>
                                <td><?php echo e($act->steal); ?></td>
                                <td><?php echo e($act->block); ?></td>
                                <td><?php echo e($act->rebound); ?></td>
                                <td>
                                    <a class="btn btn-danger" href="<?php echo e(url('delete',array($act->id_pemain))); ?>">Delete</a>
                                    <a class="btn btn-warning" href="<?php echo e(url('edit',array($act->id_pemain))); ?>">Edit</a>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->



    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="#">Logout</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaihanWisesa\resources\views/dashboard/activity.blade.php ENDPATH**/ ?>