

<?php $__env->startSection('title', 'Ubah Data Aktivitas'); ?>
<?php $__env->startSection('content'); ?>

<body id="page-top">
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <h3 style="font-weight: bold;">Form Ubah Data Aktivitas Pemain</h3>
            </div>
            <div class="col-md-6">
                <p class="text-right"><a href="<?php echo e(route('activity.index')); ?>" class="btn btn-secondary">Kembali</a></p>
            </div>
        </div>
        <!-- Content Row -->
        <form method="POST" action="<?php echo e(route('activity.update', $activity[0]->id_pemain)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="hidden" name="id_pemain" value="<?php echo e($activity[0]->id_pemain); ?>">
                <input value="<?php echo e($activity[0]->nama); ?>" type="text" class="form-control" id="nama" placeholder="Masukkan Nama Pemain" name="nama" readonly>
            </div>
            <div class="form-group">
                <label for="point">Point</label>
                <input value="<?php echo e($activity[0]->point); ?>" type="text" class="form-control" id="point" placeholder="Masukkan Total Point Pemain" name="point">
            </div>
            <div class="form-group">
                <label for="assist">Assist</label>
                <input value="<?php echo e($activity[0]->assist); ?>" type="text" class="form-control" id="assist" placeholder="Masukkan Total Assist Pemain" name="assist">
            </div>
            <div class="form-group">
                <label for="steal">Steal</label>
                <input value="<?php echo e($activity[0]->steal); ?>" type="text" class="form-control" id="steal" placeholder="Masukkan Total Steal Pemain" name="steal">
            </div>
            <div class="form-group">
                <label for="block">Block</label>
                <input value="<?php echo e($activity[0]->block); ?>" type="text" class="form-control" id="block" placeholder="Masukkan Total Block Pemain" name="block">
            </div>
            <div class="form-group">
                <label for="rebound">Rebound</label>
                <input value="<?php echo e($activity[0]->rebound); ?>" type="text" class="form-control" id="rebound" placeholder="Masukkan Total Rebound Pemain" name="rebound">
            </div>
            <button class="btn btn-success float-right mb-5" type="submit">Ubah Data Pemain</button>

        </form>
    </div>

</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\candramawa\resources\views/dashboard/ubahdata_pemain.blade.php ENDPATH**/ ?>