

<?php $__env->startSection('content'); ?>

<div class="container">
    <h3 class="text-center">About the developer</h3>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\candramawa\resources\views/about.blade.php ENDPATH**/ ?>