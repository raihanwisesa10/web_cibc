

<?php $__env->startSection('content'); ?>

<div class="container mt-4" style="margin-bottom: 111px;">
    <h3 class="text-center">Tabel Aktivitas Pemain</h3>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Point</th>
                <th scope="col">Assist</th>
                <th scope="col">Steal</th>
                <th scope="col">Block</th>
                <th scope="col">Rebound</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($act->id_pemain); ?></th>
                <td><?php echo e($act->nama); ?></td>
                <td><?php echo e($act->point); ?></td>
                <td><?php echo e($act->assist); ?></td>
                <td><?php echo e($act->steal); ?></td>
                <td><?php echo e($act->block); ?></td>
                <td><?php echo e($act->rebound); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaihanWisesa\resources\views/activity.blade.php ENDPATH**/ ?>