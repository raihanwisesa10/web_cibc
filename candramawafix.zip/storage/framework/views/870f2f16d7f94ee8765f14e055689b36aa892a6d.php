

<?php $__env->startSection('title', 'Ubah Data Aktivitas'); ?>
<?php $__env->startSection('content'); ?>

<body id="page-top">
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <h3 style="font-weight: bold;">Form Ubah Data Profil Pemain</h3>
            </div>
            <div class="col-md-6">
                <p class="text-right"><a href="<?php echo e(route('profile.index')); ?>" class="btn btn-secondary">Kembali</a></p>
            </div>
        </div>
        <!-- Content Row -->
        <form method="POST" action="<?php echo e(route('profile.update', $profiles->id_pemain)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input value="<?php echo e($profiles->nama); ?>" type="text" class="form-control" id="nama" placeholder="Masukkan Nama Pemain" name="nama" required>
            </div>
            <div class="form-group">
                <label for="umur">Umur</label>
                <input value="<?php echo e($profiles->umur); ?>" type="text" class="form-control" id="umur" placeholder="Masukkan Umur Pemain" name="umur" required>
            </div>
            <div class="form-group">
                <label for="tinggi">Tinggi</label>
                <input value="<?php echo e($profiles->tinggi); ?>" type="text" class="form-control" id="tinggi" placeholder="Masukkan tinggi Pemain" name="tinggi" required>
            </div>
            <div class="form-group">
                <label for="nama">Berat</label>
                <input value="<?php echo e($profiles->berat); ?>" type="text" class="form-control" id="berat" placeholder="Masukkan berat Pemain" name="berat" required>
            </div>
            <div class="form-group">
                <label for="nama">Posisi</label>
                <select class="form-control <?php $__errorArgs = ['posisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="posisi" name="posisi" required>
                    <?php if($profiles->posisi !=null): ?>
                    <option value="<?php echo e($profiles->posisi); ?>" selected><?php echo e($profiles->posisi); ?></option>
                    <?php else: ?>
                    <option value="" disabled selected>Pilih Posisi</option>
                    <?php endif; ?>
                    <option value="Point Guard">Point Guard</option>
                    <option value="Shooting Guard">Shooting Guard</option>
                    <option value="Small Guard">Small Forward</option>
                    <option value="Power Forward">Power Forward</option>
                    <option value="Center">Center</option>
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input value="<?php echo e($profiles->tanggal_lahir); ?>" type="date" class="form-control" id="tanggal_lahir" placeholder="Masukkan Tanggal Lahir Pemain" name="tanggal_lahir" required>
            </div>
            <div class="form-group">
                <label for="nomor_punggung">Nomor Punggung</label>
                <input value="<?php echo e($profiles->nomor_punggung); ?>" type="text" class="form-control" id="nomor_punggung" placeholder="Masukkan Nomor Punggung Pemain" name="nomor_punggung" required>
            </div>
            <div class="form-group">
                <label for="foto" style="margin-right: 40px;">Foto :</label>
                <img src="<?php echo e(asset('upload/profiles/'.$profiles->foto)); ?>" alt="Image" width="200px" height="auto" style="margin-bottom: 20px;"/>
                <input value="<?php echo e($profiles->foto); ?>" type="file" class="form-control" id="foto" placeholder="Masukkan Foto Pemain" name="foto">
                <input type="hidden" name="hidden_image" value="<?php echo e($profiles->foto); ?>">
            </div>
            <button class="btn btn-success float-right mb-5" type="submit" name="edit" value="Edit">Ubah Data Pemain</button>
        </form>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\candramawa\resources\views/dashboard/ubahdata_profil.blade.php ENDPATH**/ ?>